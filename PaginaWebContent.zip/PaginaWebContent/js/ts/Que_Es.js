// Obtener elementos del DOM
const buttHamb = document.getElementById("hamburger");
const navHam = document.getElementById('hamburger_items');
const body = document.body;
const cerrar = document.getElementById('cerrar');
const imgCerrar = document.getElementById('cerrarImg');

// Función para abrir el menú de hamburguesa
buttHamb.addEventListener("click", () => {
  navHam.style.visibility = "visible";
  body.style.backgroundColor = "rgba(0, 0, 0, 0.5)";
  cerrar.style.visibility = "visible";
  imgCerrar.style.width = "36px";
  
  if (window.innerWidth > 950) {
    // Propiedades para pantallas mayores de 950px
    navHam.style.width = "30vw";
    navHam.style.marginLeft = "75vw";
  } else {
    // Propiedades para pantallas menores de 950px
    navHam.style.width = "80vw";
    navHam.style.marginLeft = "20vw";
  }
  
  navHam.style.animation = ""; // Eliminar animación si no es necesaria
});

// Función para cerrar el menú de hamburguesa
cerrar.addEventListener('click', () => {
  navHam.style.visibility = "hidden";
  body.style.transition = "all 1s";
  body.style.backgroundColor = "initial";
  imgCerrar.style.width = "0";
  cerrar.style.visibility = "hidden";
  navHam.style.width = "20vw";
  navHam.style.marginLeft = "80vw";
  navHam.style.animation = "fadeOut 2s"; // Aplicar animación de salida
});


// Función para manejar el despliegue de menús desplegables
document.querySelectorAll('.h2-drop').forEach(button => {
  button.addEventListener('click', () => {
    const menuId = button.getAttribute('data-target');
    const menu = document.getElementById(menuId);
    const arrow = button.querySelector('.arrow-1');
    arrow.classList.toggle('arrow-1-open');
    menu.classList.toggle('open');
  });
});

// Función para desplazar la página a un elemento específico cuando se carga la página
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    const id = window.location.hash.substring(1);
    if (id) {
      const targetElement = document.getElementById(id);
      if (targetElement) {
        targetElement.scrollIntoView({
          block: 'center',
          inline: 'center'
        });
      }
    }
  }, 200);
});
